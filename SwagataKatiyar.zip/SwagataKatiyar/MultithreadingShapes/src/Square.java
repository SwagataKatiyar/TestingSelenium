public class Square extends Shapes {

	
	public Square(int side)
	{
		super(side);
	}
	
   public int calcArea()
   {
	  return this.getSide1() * this.getSide1();
   }
	
	
	public int calcPerimeter()
	{
		return this.getSide1() * 4;
	}
	
}
