public class Rectangle extends Shapes{
	
	public Rectangle(int side1,int side2)
	{
		super(side1,side2);
	}
	
	public int calcArea()
	{
		System.out.println("calulating area of rectangle..");
		return this.getSide1() *  this.getSide2();
	}
	
	public int calcPerimeter()
	{
		System.out.println("calulating perimeter of rectangle..");
		return 2* (this.getSide1() + this.getSide2());
	}
	

}